#include <iostream>
#include <string>
#pragma once
using namespace std;

class MyDate
{
private:
	int _day;
	int _month;
	int _year;
	char* _msg;
public:
	int getDay() const															   	 // inline.
	{
		return this->_day;
	}
	int getMonth() const															 // inline.
	{
		return this->_month;
	}
	int getYear() const																 // inline.
	{
		return this->_year;
	}
	char* getMsg() const															 // inline.
	{
		return this->_msg;
	}
	bool validMonth(int day,int month);											     // Match each month the Max day
	bool setDay(int day);															 // Set the day.
	bool setMonth(int month);														 // Set the month.
	bool setYear(int year);															 // Set the year.
	void setMsg(const char* msg);													 // Set the comment.
	void setDate(int year, int month, int day);										 // Set date 
	void setDate(MyDate& date);														 // Set the date.
	MyDate& incDate();																 // Increment the date;
	MyDate& initDate();																 // Set the date to the submission date.
	bool isBefore(MyDate& date) const;												 // Check if the date is before the present date.
	void changeComment(const char* comment);										 // Change the comment.
	void printDate() const;															 // Print date.
	MyDate(int day, int month, int year, const char* comment);						 // Constructor.
	MyDate();																		 // Default constructor.
	MyDate(const MyDate& date);														 // Copy constructor.
	~MyDate();											   							 // Destructor.

};
