#include "Calander.h"

bool Calander :: isFree(int num) const
{
	if (this->_calander[num] == NULL)
		return true;
	else
		return false;
}
int  Calander :: firstFree()const
{
	if ((this->_occupied < 30))
	{
		for (int i = 0; i < SIZE; i++)
			if (this->_calander[i] == NULL)
				return i;
	}
	return -1;
}
bool Calander :: insert(const MyDate* date) 
{
	int firstVacant = firstFree();
	if (firstVacant == -1)
		return false;
	else
	{
		this -> setDate(date, firstVacant);
		return true;
	}
}
int  Calander :: oldest() const
{
	int counter = this->_occupied;
	int min = 0;
	if (this->_occupied == 0)
		min = -1;
	while (counter)
	{
		if (this->_calander[counter] != NULL)
		{
			min = counter;
			break;
		}
		counter -= 1;
	}
	for (int i = 0; min != -1 && i < SIZE; i++)
	{
		
		if (this->_calander[i] != NULL)
		{
			if (!(this->_calander[min]->isBefore(*this->_calander[i])))
				min = i;
		}
	}
	return min;
}
int  Calander::datesNum() const
{
	int counter = 0;
	for (int i = 0; i < SIZE; i++)
	{
		if (this->_calander[i] != NULL)
			counter += 1;
	}
	return counter;
}
void Calander::setDate(const MyDate* date, int num) 
{
	if (num < 0 || num >= SIZE)
	{
		cout << " The index is out of range" << endl;
		return;
	}
	else
	{
		this->_calander[num] = new MyDate(*date);
		this->_occupied += 1;
	}
	
}
void Calander::deleteAll() 
{
	for (int i = 0 ;i < SIZE ;i++)
	{

		if (this->_calander[i] != NULL)
		{
			delete this->_calander[i];
			this->_occupied -= 1 ;
		}
	}
}
void Calander :: deleteIndex(int num) 
{
	if (!(num < 0 || num >= 30))
	{
		if (this->_calander[num] != NULL)
		{
			delete this->_calander[num];
			this->_calander[num] = NULL;
			this->_occupied -= 1;
		}
	}

}
void Calander :: print() const
{
	if (this->_occupied)
		for (int i = 0; i < SIZE;i++)
		{
			if (this->_calander[i] != NULL)
			{
				cout << "Calander["<<i << "] :";
				this->_calander[i]->printDate();
			}
		}
	else
		cout << "Empty Calander" << endl;
}

Calander::Calander()
{
	this->_occupied = 0;
	for (int i = 0; i < SIZE;i++)
		this->_calander[i] = NULL;
	
}
	
Calander::Calander(const Calander& calander)
{
	this->_occupied = 0;
	for (int i = 0;i < SIZE;i++)
		if (calander.isFree(i))
			this->_calander[i] = NULL;
		else
		{
			this->_calander[i] = new MyDate(*(calander.getDate(i)));
			this->_occupied += 1;
		}

}
