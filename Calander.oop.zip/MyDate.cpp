#include "MyDate.h"
bool MyDate :: validMonth(int day,int month)
{
	int arrMonth[13];
	arrMonth[0] = 0;
	for (int i = 1; i < 13; i++)
	{
		if (i == 4 || i == 6 || i == 9 || i == 11)
			arrMonth[i] = 30;
		if (i == 1 || i== 3 || i == 5 || i == 7 || i == 8 || i == 10 || i == 12)
			arrMonth[i] = 31;
		if (i == 2)
			arrMonth[i] = 28;
	}
	if (day > arrMonth[month])
		return false;
	return true;

}
bool MyDate :: setDay(int day)
{
	if (day >= 1 && day <= 31)
	{
		this ->_day = day;
		return true;
	}
	return false;
}
bool MyDate :: setMonth(int month)
{
	
	if (month >= 1 && month <= 12)
	{
		this->_month = month;
		return true;
	}
	return false;
	
}
bool  MyDate :: setYear(int year)
{
	
	if (year >= 0 )
	{
		this->_year = year;
		return true;
	}
	return false;
	
}
void MyDate :: setMsg(const char* comment)
{
	if (this->getMsg() != NULL)
		delete _msg;
	if (comment == NULL)
	{
		this->_msg = new char[strlen("NoComment") + 1];
		strcpy_s(this->_msg, strlen("NoComment") + 1,"NoComment");	
	}
    else
	{
		this->_msg = new char[strlen(comment) + 1];
		strcpy_s(this->_msg, strlen(comment) + 1, comment);
	}
	

}
void MyDate::setDate(int year, int month, int day)
{
	if (!(setYear(year)))
		this->_year = 1;
	else
		this->_year = year;
	if (!(setMonth(month)))
		this->_month = 1;
	else
		this->_month = month;
	if ((!(setDay(day))) || !(validMonth(day, month)))
		this->_day = 1;
	else
		this->_day = day;

}
void MyDate :: setDate(MyDate& date)
{
	this->_year = date.getYear();
	this->_month = date.getMonth();
	this->_day = date.getDay();
	this->setMsg(date._msg);
}
MyDate& MyDate :: incDate()
{
	this->_day = this->_day + 1;
	if (!(validMonth(this->_day, this->_month)))
	{	
		this->_day = 1;
		this->_month = this->_month + 1;
		if (this->_month > 12)
		{
			this->_month = 1;
			this->_year = this->_year + 1;
		}

	}
	return *this;
}
MyDate& MyDate::initDate()
{
	this->setDay(19);
	this->setMonth(12);
	this->setYear(2021);
	this->setMsg("Submission date");
	return *this;
}
bool MyDate ::  isBefore(MyDate& date) const
{
	if (this->_year < date.getYear())
		return true;
	else if (this->_year == date.getYear() && this->_month < date.getMonth())
		return true;
	else if (this->_year == date.getYear() && this->_month == date.getMonth())
		return (this->_day < date.getDay());
	else return false;
}
void  MyDate ::  changeComment(const char* comment)
{
	this -> setMsg(comment);
}
void MyDate::printDate() const
{
	
	if (getDay() < 10 && getMonth() < 10)
		cout << "The Date is : " << "0" << this->getDay() << "/" << "0" << this->getMonth();
	else if (getDay() > 10  && getMonth() < 10)
		cout << "The Date is : "<< this->getDay() << "/" << "0" << this->getMonth();
	else if (getDay() < 10 && getMonth() > 10)
		cout << "The Date is : " << "0" << this->getDay() << "/" << this->getMonth();
	else
		cout << "The Date is : " << this->getDay() << "/" << this->getMonth();
	if (getYear() < 10)
		cout << "/000" << this->getYear() << endl;
	else if (getYear() > 10 && getYear() < 100)
		cout << "/00" << this->getYear() << endl;
	else if (getYear() > 100 && getYear() < 1000)
		cout << "/0" << this->getYear() << endl;
	else
		cout << "/" << this->getYear() << endl;
	cout << "Comment: " << this->getMsg() << endl;
}
MyDate:: MyDate(int year,int month,int day,const char* comment)
{
	this->setMsg(comment);
	setDate(year, month, day);
}
MyDate:: MyDate()
{
	this->_day = 1;
	this->_month = 1;
	this->_year = 2020;
	this->_msg = new char[strlen("NoComment") + 1];
	strcpy_s(this->_msg, strlen("NoComment") + 1, "NoComment");	
}
MyDate:: MyDate(const MyDate& date)
{ 
	this->_day = date.getDay();
	this->_month = date.getMonth();
	this->_year= date.getYear();
	if (date.getMsg() == NULL)
		this->_msg == NULL;
	else
	{
		this->_msg = new char[strlen(date._msg) + 1];
		strcpy_s(this->_msg, strlen(date._msg) + 1, date._msg);
	}
}
MyDate :: ~MyDate()
{
	if (this->getMsg() != NULL)
		delete this->_msg;		
}
