#include "Calander.h"


// Ahigad Genish


int main()
{
	
	MyDate A(1997,3, 17, "A Birthday");
	MyDate B(1997, 5, 5, "B Birthday");
	MyDate C(2022, 1, 16, "Complex function exam");
	MyDate D, E(B), F;
	D.setDate(A);
	D.incDate();
	D.changeComment(NULL);
	E.initDate();
	MyDate G(-2020, 2, 31, "illegal date is changed");
	MyDate H(2021, 12, 31, "Silvester");
	H.incDate();
	H.setMsg("Happy new year");
	Calander Y;
	Y.insert(&A);
	Y.insert(&B);
	Y.insert(&C);
	Y.insert(&D);
	Y.insert(&E);
	Y.insert(&F);
	Y.insert(&G);
	Y.insert(&H);
	Y.print();
	cout << "The first free is: " << Y.firstFree() << endl;
	cout << "check if clander[4] is free: ";
	(Y.isFree(4)) ? (cout << "yes" << endl) : cout << "no" << endl;
	cout << "check if clander[19] is free: ";
	(Y.isFree(19)) ? (cout << "yes" << endl) : cout << "no" << endl;
	cout << "The DatesNum is: " << Y.datesNum() << endl;
	cout << "The oldest is: " << Y.oldest() << endl;
	Y.deleteIndex(Y.oldest());
	cout << "******* Delete the oldest *******" << endl;
	Y.print();
	cout << "The first free is: " << Y.firstFree() << endl;
	cout << "The oldest is: " << Y.oldest() << endl;
	Y.deleteAll();
	cout << "The DatesNum is: " << Y.datesNum() << endl;
	cout << "******* deleteAll*******" << endl;
	Y.print();

	
	


	
}