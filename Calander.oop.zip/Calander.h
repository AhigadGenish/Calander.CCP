#include "MyDate.h"
#pragma once
#define SIZE 30
class Calander
{
private:
	MyDate* _calander[SIZE];
	int _occupied;

public:
	int getOccupied()												// inline
	{
		return this->_occupied;
	}
	MyDate* getDate(int index)const						     		// inline
	{
		return this->_calander[index];
	}
	bool isFree(int num) const;										// Check if this index are free.
	int  firstFree()const;											// Return the first free index.
	bool insert(const MyDate* date);								// Insert in the first free index.
	int  oldest()const;												// Return the index where is the oldest date.
	int  datesNum()const;											// Return the num of occupied dates.
	void setDate(const MyDate* date, int num);						// Set date in the chosen index.
	void deleteAll();												// Delete all calander array.
	void deleteIndex(int num);										// Delete the date in the chosen index.
	void print()const;												// Print the calander.
	Calander();														// Constructor.
	Calander(const Calander& calander);								// Default constructor.
};

